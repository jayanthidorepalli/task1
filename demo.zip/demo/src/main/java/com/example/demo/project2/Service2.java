package com.example.demo.project2;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

@Service
public class Service2 {
int a; int b;

public int getB() {
	return b;
}

public void setB(int b) {
	this.b = b;
}

public int getA() {
	return a;
}

public void setA(int a) {
	this.a = a;
}
public ArrayList div2() {
	ArrayList<String> al=new ArrayList<>();
	try {
		int c=a/b;
		al.add("Output"+c);
	}
	catch(Exception e) {
		al.add("Exception is"+e.toString());
	}
	return al;
}
}
