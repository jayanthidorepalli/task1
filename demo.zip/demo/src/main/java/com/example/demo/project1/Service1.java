package com.example.demo.project1;

import org.springframework.stereotype.Service;

@Service 
public class Service1 {
int add(int a, int b) {
	return a+b;
}


}
