package com.example.demo.project2;

import java.util.ArrayList;
import java.util.HashMap;

public class Objclass {

	int a; int b;


	public int getA() {
		return a;
	}


	public void setA(int a) {
		this.a = a;
	}


	 
	public void setB(int b) {
		this.b = b;
	}
	int x,y;
	int method() {
		return x+y;
	}
	
	
	public ArrayList div() {
		ArrayList<String> al=new ArrayList<>();
		try {
			int c=a/b;
			al.add("Output"+" "+c);
		}
		catch(Exception e) {
			al.add("Exception is"+e.toString());
		}
		return al;
	}
}
