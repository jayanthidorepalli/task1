package com.example.demo.project1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class Controller1 {
	@GetMapping("/")
	String name() {
		return "welcome to mss";
	}
	@Autowired
	Service1 service;
	@GetMapping("/add/{a}/{b}")
	String add(@PathVariable int a, @PathVariable int b){
		
		return "sum"+"="+service.add(a,b);
	}
	@GetMapping("/sub/{a}/{b}")
	int sub(@PathVariable int a, @PathVariable int b) {
		return a-b;
	}
	@GetMapping("/subb")
	int subb(@RequestParam int a, @RequestParam int b) {
		return a-b;
	}
	
}
